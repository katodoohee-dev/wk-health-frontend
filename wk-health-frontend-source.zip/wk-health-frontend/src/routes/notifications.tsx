import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/wk/app-shell";
import { Chip, Eyebrow, Panel, SectionHeader } from "@/components/wk/primitives";
import { notifications } from "@/lib/wk-data";

export const Route = createFileRoute("/notifications")({
  head: () => ({
    meta: [
      { title: "Notifications — WK Health" },
      {
        name: "description",
        content: "Signals, not noise: insights, coaching and system events in one calm timeline.",
      },
      { property: "og:title", content: "Notifications — WK Health" },
      { property: "og:description", content: "A restrained timeline of everything WK noticed." },
    ],
  }),
  component: NotificationsPage,
});

const filters = ["All", "Insight", "Coach", "Social", "System"];

function NotificationsPage() {
  return (
    <AppShell eyebrow="Timeline" title="Notifications">
      <div className="grid gap-6 lg:grid-cols-[minmax(0,1.6fr)_minmax(0,1fr)]">
        <div>
          <div className="flex flex-wrap gap-2">
            {filters.map((f, i) => (
              <button
                key={f}
                type="button"
                aria-pressed={i === 0}
                className={
                  i === 0
                    ? "min-h-11 rounded-full bg-foreground px-4 text-sm text-background"
                    : "min-h-11 rounded-full border border-border px-4 text-sm text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
                }
              >
                {f}
              </button>
            ))}
          </div>

          <ul className="mt-8 divide-y divide-border">
            {notifications.map((n) => (
              <li key={n.id} className="grid grid-cols-[auto_minmax(0,1fr)_auto] items-start gap-4 py-5">
                <span
                  className={
                    n.unread
                      ? "mt-2 size-2 shrink-0 rounded-full bg-foreground"
                      : "mt-2 size-2 shrink-0 rounded-full border border-border-strong"
                  }
                  aria-hidden="true"
                />
                <div className="min-w-0">
                  <Eyebrow>{n.kind}</Eyebrow>
                  <p className="display mt-1.5 text-xl">{n.title}</p>
                  <p className="mt-1 text-sm text-muted-foreground">{n.body}</p>
                </div>
                <span className="numeric shrink-0 text-xs text-muted-foreground">{n.time}</span>
              </li>
            ))}
          </ul>
        </div>

        <aside className="flex flex-col gap-6">
          <Panel className="grain flex flex-col gap-6">
            <Chip tone="signal">Quiet hours active</Chip>
            <div>
              <Eyebrow>Unread</Eyebrow>
              <p className="numeric mt-2 text-6xl font-medium">02</p>
            </div>
            <p className="text-sm text-muted-foreground">
              WK batches non-urgent signals into one morning digest at 07:00 and holds everything
              between 22:00 and 06:30.
            </p>
            <button
              type="button"
              className="inline-flex min-h-11 w-fit items-center rounded-full border border-border px-5 text-sm transition-colors hover:bg-accent"
            >
              Mark all as read
            </button>
          </Panel>

          <div>
            <SectionHeader eyebrow="Delivery" title="Channels" />
            <dl className="divide-y divide-border">
              {[
                ["Watch haptics", "Urgent only"],
                ["Push", "Insights + coach"],
                ["Morning digest", "07:00"],
                ["Email", "Off"],
              ].map(([k, v]) => (
                <div key={k} className="flex items-center justify-between gap-4 py-4">
                  <dt className="text-sm">{k}</dt>
                  <dd className="text-xs text-muted-foreground">{v}</dd>
                </div>
              ))}
            </dl>
          </div>
        </aside>
      </div>
    </AppShell>
  );
}
