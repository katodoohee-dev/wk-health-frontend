import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { ArrowUp, Paperclip } from "lucide-react";
import { AppShell } from "@/components/wk/app-shell";
import {
  Chip,
  Eyebrow,
  LoadingState,
  Panel,
  SectionHeader,
  SuccessState,
} from "@/components/wk/primitives";
import { VoicePanel, type VoiceState } from "@/components/wk/voice";
import { assistantSuggestions, assistantThread } from "@/lib/wk-data";

export const Route = createFileRoute("/assistant")({
  head: () => ({
    meta: [
      { title: "Assistant — WK Health" },
      {
        name: "description",
        content:
          "The WK assistant reads your vitals, training load and sleep to answer health questions in context.",
      },
      { property: "og:title", content: "Assistant — WK Health" },
      {
        property: "og:description",
        content: "Voice and text guidance grounded in your own health signals.",
      },
    ],
  }),
  component: AssistantPage,
});

const cycle: VoiceState[] = ["idle", "listening", "thinking", "speaking"];

function AssistantPage() {
  const [voice, setVoice] = useState<VoiceState>("listening");

  return (
    <AppShell eyebrow="Conversation" title="WK Assistant">
      <div className="grid gap-6 lg:grid-cols-[minmax(0,1.5fr)_minmax(0,1fr)]">
        <div className="flex flex-col gap-6">
          <Panel className="grain flex flex-col gap-8 lg:p-8">
            <div className="flex flex-wrap items-center gap-2">
              <Chip tone="solid">Context on</Chip>
              <Chip>Sleep · HRV · Load · Calendar</Chip>
            </div>

            <ul className="flex flex-col gap-8">
              {assistantThread.map((m) => (
                <li
                  key={m.id}
                  className={m.role === "user" ? "flex justify-end" : "flex justify-start"}
                >
                  <div className={m.role === "user" ? "max-w-[85%]" : "max-w-[92%]"}>
                    <Eyebrow className="mb-2">{m.role === "user" ? "You" : "WK"}</Eyebrow>
                    <p
                      className={
                        m.role === "user"
                          ? "rounded-2xl rounded-tr-sm bg-foreground px-4 py-3 text-[0.9375rem] leading-relaxed text-background"
                          : "display text-2xl leading-tight sm:text-[1.75rem]"
                      }
                    >
                      {m.text}
                    </p>
                    {"citations" in m && m.citations ? (
                      <div className="mt-4 flex flex-wrap gap-2">
                        {m.citations.map((c) => (
                          <Chip key={c}>{c}</Chip>
                        ))}
                      </div>
                    ) : null}
                  </div>
                </li>
              ))}
              <li>
                <Eyebrow className="mb-3">WK</Eyebrow>
                <LoadingState label="Reading your route history" />
              </li>
            </ul>

            <div className="rounded-2xl border border-border bg-surface-2 p-2">
              <label htmlFor="wk-prompt" className="sr-only">
                Message WK
              </label>
              <div className="flex items-end gap-2">
                <button
                  type="button"
                  aria-label="Attach data source"
                  className="grid size-11 shrink-0 place-items-center rounded-full text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
                >
                  <Paperclip className="size-4" aria-hidden="true" />
                </button>
                <textarea
                  id="wk-prompt"
                  rows={1}
                  placeholder="Ask about recovery, training, sleep…"
                  className="max-h-32 min-h-11 flex-1 resize-none bg-transparent py-3 text-sm placeholder:text-muted-foreground focus:outline-none"
                />
                <button
                  type="button"
                  aria-label="Send message"
                  className="grid size-11 shrink-0 place-items-center rounded-full bg-foreground text-background transition-transform hover:scale-105"
                >
                  <ArrowUp className="size-4" aria-hidden="true" />
                </button>
              </div>
            </div>
          </Panel>
        </div>

        <aside className="flex flex-col gap-6">
          <VoicePanel
            state={voice}
            onCycle={() => setVoice((s) => cycle[(cycle.indexOf(s) + 1) % cycle.length] ?? "idle")}
          />
          <div>
            <SectionHeader eyebrow="Starters" title="Try asking" />
            <ul className="mt-2 divide-y divide-border">
              {assistantSuggestions.map((s) => (
                <li key={s}>
                  <button
                    type="button"
                    className="flex min-h-11 w-full items-center justify-between gap-3 py-3.5 text-left text-sm transition-colors hover:text-muted-foreground"
                  >
                    <span className="min-w-0">{s}</span>
                    <ArrowUp className="size-3.5 shrink-0 rotate-45 text-muted-foreground" aria-hidden="true" />
                  </button>
                </li>
              ))}
            </ul>
          </div>
          <SuccessState
            title="Plan accepted"
            body="6 × 3 min threshold added to today at 17:30 with a shaded route."
          />
        </aside>
      </div>
    </AppShell>
  );
}
