import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/wk/app-shell";
import { Chip, EmptyState, Eyebrow, Panel, SectionHeader, Sparkline } from "@/components/wk/primitives";
import { friends } from "@/lib/wk-data";

export const Route = createFileRoute("/friends")({
  head: () => ({
    meta: [
      { title: "Friends — WK Health" },
      {
        name: "description",
        content: "A quiet social layer: shared streaks, weekly standings and encouragement without noise.",
      },
      { property: "og:title", content: "Friends — WK Health" },
      { property: "og:description", content: "Shared movement, quietly presented." },
    ],
  }),
  component: FriendsPage,
});

function FriendsPage() {
  return (
    <AppShell eyebrow="Social layer" title="Friends">
      <section className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.4fr)]">
        <Panel className="grain flex flex-col justify-between gap-10">
          <Chip tone="solid">Week 34 standing</Chip>
          <div>
            <Eyebrow>Your rank</Eyebrow>
            <p className="numeric mt-3 text-7xl font-medium">02</p>
            <p className="mt-3 text-sm text-muted-foreground">
              412 active minutes — 34 behind Mina S. with two days left.
            </p>
          </div>
          <Sparkline data={[210, 260, 288, 320, 356, 390, 412]} />
        </Panel>

        <div>
          <SectionHeader eyebrow="Circle" title="Four people" action={<Chip>Live</Chip>} />
          <ul className="divide-y divide-border">
            {friends.map((f) => (
              <li
                key={f.id}
                className="grid grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-4 py-5"
              >
                <span className="numeric grid size-11 shrink-0 place-items-center rounded-full border border-border text-xs">
                  {f.initials}
                </span>
                <div className="min-w-0">
                  <p className="truncate text-sm font-medium">{f.name}</p>
                  <p className="truncate text-xs text-muted-foreground">{f.status}</p>
                </div>
                <div className="shrink-0 text-right">
                  <p className="numeric text-lg">{f.readiness}</p>
                  <p className="eyebrow">{f.streak} day streak</p>
                </div>
              </li>
            ))}
          </ul>
        </div>
      </section>

      <section className="mt-14">
        <SectionHeader eyebrow="Invitations" title="Nothing pending" />
        <div className="mt-6">
          <EmptyState
            title="No requests right now"
            body="Invites appear here. WK never shares raw health data — only the metrics you choose."
            action={
              <button
                type="button"
                className="mt-2 inline-flex min-h-11 items-center rounded-full border border-border px-5 text-sm transition-colors hover:bg-accent"
              >
                Share invite link
              </button>
            }
          />
        </div>
      </section>
    </AppShell>
  );
}
