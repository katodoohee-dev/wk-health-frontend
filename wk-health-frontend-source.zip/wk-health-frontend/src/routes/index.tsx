import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowUpRight } from "lucide-react";
import { AppShell } from "@/components/wk/app-shell";
import {
  BarSeries,
  Chip,
  Eyebrow,
  Metric,
  Panel,
  ProgressRing,
  SectionHeader,
  StackedBar,
} from "@/components/wk/primitives";
import { activityWeek, insights, rings, sleep, vitals } from "@/lib/wk-data";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "WK Health — Your AI Health Operating System" },
      {
        name: "description",
        content:
          "WK Health turns your vitals, training and recovery into one calm, readable health operating system.",
      },
      { property: "og:title", content: "WK Health — AI Health Operating System" },
      {
        property: "og:description",
        content: "Readiness, recovery, activity and guidance in one monochrome interface.",
      },
    ],
  }),
  component: HealthOverview,
});

function HealthOverview() {
  return (
    <AppShell eyebrow="Wednesday · 19 August" title="Health overview">
      <section className="grid gap-6 lg:grid-cols-[minmax(0,1.35fr)_minmax(0,1fr)]">
        <Panel className="grain flex flex-col justify-between gap-10 lg:p-8">
          <div className="flex flex-wrap items-center gap-2">
            <Chip tone="signal">All systems nominal</Chip>
            <Chip>Synced 2 min ago</Chip>
          </div>
          <div>
            <Eyebrow>Readiness index</Eyebrow>
            <div className="mt-3 flex items-end gap-4">
              <span className="numeric text-[5.5rem] leading-[0.85] font-medium sm:text-[7.5rem]">
                87
              </span>
              <span className="pb-3 text-sm text-muted-foreground">/ 100</span>
            </div>
            <p className="mt-6 max-w-lg text-[0.9375rem] leading-relaxed text-muted-foreground">
              Recovery is ahead of load for the third day running. Your body is prepared for
              intensity — WK suggests a threshold block before 18:00.
            </p>
          </div>
          <Link
            to="/assistant"
            className="inline-flex w-fit items-center gap-2 rounded-full bg-foreground px-5 py-3 text-sm font-medium text-background transition-transform hover:scale-[1.02]"
          >
            Ask WK about today
            <ArrowUpRight className="size-4" aria-hidden="true" />
          </Link>
        </Panel>

        <div className="grid grid-cols-2 gap-6">
          {vitals.map((v) => (
            <Panel key={v.id} className="animate-rise">
              <Metric label={v.label} value={v.value} unit={v.unit} delta={v.delta} trend={v.trend} />
            </Panel>
          ))}
        </div>
      </section>

      <section className="mt-14">
        <SectionHeader
          eyebrow="Today"
          title="Movement rings"
          action={
            <Link to="/activity" className="text-sm underline underline-offset-4">
              Full activity
            </Link>
          }
        />
        <div className="mt-8 grid gap-6 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.2fr)]">
          <Panel className="flex items-center justify-around gap-4 py-8">
            {rings.map((r) => (
              <ProgressRing key={r.id} {...r} size={124} />
            ))}
          </Panel>
          <Panel>
            <div className="flex items-end justify-between gap-4">
              <div>
                <Eyebrow>Active minutes · this week</Eyebrow>
                <p className="numeric mt-2 text-4xl font-medium">411</p>
              </div>
              <Chip>+18% vs last week</Chip>
            </div>
            <div className="mt-8">
              <BarSeries data={activityWeek} />
            </div>
          </Panel>
        </div>
      </section>

      <section className="mt-14 grid gap-6 lg:grid-cols-[minmax(0,1fr)_minmax(0,1fr)]">
        <Panel className="self-start">
          <div className="flex items-end justify-between gap-4">
            <div>
              <Eyebrow>Sleep · last night</Eyebrow>
              <p className="numeric mt-2 text-4xl font-medium">{sleep.score}</p>
            </div>
            <p className="numeric text-sm text-muted-foreground">{sleep.duration}</p>
          </div>
          <div className="mt-8">
            <StackedBar segments={sleep.stages} />
          </div>
        </Panel>

        <div>
          <SectionHeader eyebrow="Signals" title="What WK noticed" />
          <ul className="mt-4 divide-y divide-border">
            {insights.map((i) => (
              <li key={i.id} className="group py-5">
                <Eyebrow>{i.tag}</Eyebrow>
                <h3 className="display mt-2 text-xl">{i.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{i.body}</p>
              </li>
            ))}
          </ul>
        </div>
      </section>
    </AppShell>
  );
}
