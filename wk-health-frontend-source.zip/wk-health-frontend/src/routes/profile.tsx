import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/wk/app-shell";
import { Chip, Eyebrow, Panel, SectionHeader, Sparkline } from "@/components/wk/primitives";
import { user } from "@/lib/wk-data";

export const Route = createFileRoute("/profile")({
  head: () => ({
    meta: [
      { title: "Profile — WK Health" },
      {
        name: "description",
        content: "Your baselines, connected devices and long-term health trajectory in WK Health.",
      },
      { property: "og:title", content: "Profile — WK Health" },
      { property: "og:description", content: "Baselines, devices and milestones." },
    ],
  }),
  component: ProfilePage,
});

const baselines = [
  { label: "VO₂ max", value: "54.2", unit: "ml/kg/min" },
  { label: "Resting HR baseline", value: "56", unit: "bpm" },
  { label: "HRV baseline", value: "61", unit: "ms" },
  { label: "Threshold pace", value: "4:22", unit: "/km" },
];

const devices = [
  { name: "WK Band 2", detail: "Battery 78% · synced 2m ago", live: true },
  { name: "Chest strap H10", detail: "Last used yesterday", live: false },
  { name: "Smart scale", detail: "Weekly weigh-in Sunday", live: false },
];

function ProfilePage() {
  return (
    <AppShell eyebrow="Account" title="Profile">
      <section className="panel grain grid gap-8 p-6 sm:p-8 lg:grid-cols-[minmax(0,1fr)_auto] lg:items-end">
        <div className="flex min-w-0 items-center gap-5">
          <span className="numeric grid size-16 shrink-0 place-items-center rounded-full border border-border text-lg sm:size-20 sm:text-xl">
            {user.initials}
          </span>
          <div className="min-w-0">
            <Eyebrow>{user.plan}</Eyebrow>
            <h2 className="display mt-1 truncate text-3xl sm:text-4xl">{user.name}</h2>
            <p className="mt-1 text-sm text-muted-foreground">
              {user.handle} · with WK since {user.since}
            </p>
          </div>
        </div>
        <div className="flex shrink-0 flex-wrap gap-2">
          <Chip tone="signal">Band connected</Chip>
          <Chip>On-device processing</Chip>
        </div>
      </section>

      <section className="mt-14">
        <SectionHeader eyebrow="Baselines" title="Your physiology" />
        <div className="mt-8 grid gap-6 sm:grid-cols-2 xl:grid-cols-4">
          {baselines.map((b) => (
            <Panel key={b.label} className="animate-rise">
              <Eyebrow>{b.label}</Eyebrow>
              <p className="numeric mt-4 text-4xl font-medium">{b.value}</p>
              <p className="eyebrow mt-1">{b.unit}</p>
            </Panel>
          ))}
        </div>
      </section>

      <section className="mt-14 grid gap-6 lg:grid-cols-[minmax(0,1.2fr)_minmax(0,1fr)]">
        <Panel>
          <Eyebrow>Twelve-month trajectory</Eyebrow>
          <p className="display mt-2 text-2xl">Readiness is compounding</p>
          <div className="mt-8">
            <Sparkline data={[62, 60, 66, 64, 69, 72, 70, 75, 78, 80, 84, 87]} height={70} className="h-24" />
          </div>
          <div className="mt-4 flex justify-between">
            <span className="eyebrow">Sep</span>
            <span className="eyebrow">Aug</span>
          </div>
        </Panel>

        <div>
          <SectionHeader eyebrow="Hardware" title="Devices" />
          <ul className="divide-y divide-border">
            {devices.map((d) => (
              <li key={d.name} className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-4 py-5">
                <div className="min-w-0">
                  <p className="truncate text-sm font-medium">{d.name}</p>
                  <p className="truncate text-xs text-muted-foreground">{d.detail}</p>
                </div>
                {d.live ? <Chip tone="signal">Live</Chip> : <Chip>Idle</Chip>}
              </li>
            ))}
          </ul>
        </div>
      </section>
    </AppShell>
  );
}
